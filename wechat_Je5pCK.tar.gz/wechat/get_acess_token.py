import requests
import json
import time

def get_acess_token():
    grant_type = "client_credential"
    appid = "wxec8d7ce946c58618"
    secret = "264abefc84add7e7a443d463613c05d2"
    url = "https://api.weixin.qq.com/cgi-bin/token?grant_type={0}&appid={1}&secret={2}".format(grant_type, appid, secret)
    
    res = requests.get(url)
    json_data = json.loads(res.txt)
    acess_token = json_data['acess_token']
    expires_in = int(json_data['expires_in'])
    
    with open('acess_token.txt', 'w', encoding='utf-8') as f:
        f.write(acess_token)

    
    
if __name__ = '__main__':
    while 1:
        get_acess_token()
        time.sleep(expires_in - 200)
