# -*- coding: utf-8 -*-
# filename: handle.py
# function: 处理业务逻辑 POST已完成,需要调用NLP接口  GET未完成
import reply
import receive
import hashlib
import web
from new_sentence_parser import *
from chatbot import *
class Handle(object):
    def __init__(self):
        self.max_length = 600
        
        
    def GET(self):
        try:
            data = web.input()
            print(data)
            if len(data) == 0:
                return "hello, this is handle view"
            signature = data.signature
            timestamp = data.timestamp
            nonce = data.nonce
            echostr = data.echostr
            token = "CAU" #请按照公众平台官网\基本配置中信息填写
            
            ls = [token, timestamp, nonce]
            ls.sort()
            tmp_str = "".join(ls)
            hashcode = hashlib.sha1(tmp_str.encode("utf-8")).hexdigest()
            print("handle/GET func: hashcode, signature: ", hashcode, signature)
            if hashcode == signature:
                return echostr
            else:
                return ""
        except Exception as Argument:
            return Argument
    
    def POST(self):
        try:
            webData = web.data()
            print("Handle Post webdata is ", webData)
            #后台打日志
            recMsg = receive.parse_xml(webData)
            if isinstance(recMsg, receive.Msg):
                toUser = recMsg.FromUserName
                fromUser = recMsg.ToUserName
                if recMsg.MsgType == 'text':
                    # 弃用版
                    # ltp = LtpParser()
                    # sents = ltp.split_sents(recMsg.Content)
                    # words, postags, child_dict_list, roles_dict, format_parse_list = ltp.parser_main([sents[0]])
                    # result = ltp.rule(words[0], postags[0], child_dict_list[0], roles_dict[0], format_parse_list[0])
                    # 正式版
                    chat = chatbot()
                    content = chat.chat_main(recMsg.FromUserName, recMsg.Content)
                    print('输出测试: ',content)
                    # 当前content仅供测试
                    # content = "您是说" + recMsg.Content + "吗[旺柴]"
                    
                    #需要设置一条信息的字数限制,当字数过多时分为多条信息发送
                    replyMsg = reply.TextMsg(toUser, fromUser, content)
                    return replyMsg.send()
                if recMsg.MsgType == 'image':
                    mediaId = recMsg.MediaId
                    replyMsg = reply.ImageMsg(toUser, fromUser, mediaId)
                    return replyMsg.send()
                else:
                    return reply.Msg().send()
            else:
                print ("暂且不处理")
                return reply.Msg().send()
        except Exception as Argment:
            return Argment