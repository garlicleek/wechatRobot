import re
from ltp import LTP


# 就先这么着,有概率认出主谓

class LtpParser:
    def __init__(self):
        self.ltp = LTP()

    def split_sents(self, content):
        # 分句
        self.ltp.init_dict(path="user_dict.txt", max_window=4)
        return self.ltp.sent_split([content])

    def rule(self, words, postags, child_dict_list, roles_dict, former_parse_list):
        S = ''
        V = ''
        # 从语法上判断主语和谓语
        for i in range(len(former_parse_list)):
            if former_parse_list[2] == 'SBV':
                S = words[former_parse_list[i][0] - 1]
                V = words[former_parse_list[i][1] - 1]

        # 从词语关系找主语
        for i in range(len(child_dict_list)):
            for j in range(len(child_dict_list[i][1])):
                if child_dict_list[i][1][j][0] == 'A1' or child_dict_list[i][1][j][0] == 'A0':
                    num = child_dict_list[i][1][j][1]
                    S = words[num]

        # 从词性找谓语
        for i in range(len(postags)):
            if postags[i] == 'v':
                V = words[i]

        # 从句意找否定词,出现否定标记mneg需要合并
        for i in range(len(roles_dict)):
            if roles_dict[i][2] == 'mNEG' and postags[roles_dict[i][1] - 1] == 'v':
                V = words[roles_dict[i][0] - 1] + V
        return [S, V]

    def parser_main(self, sentence):
        # 分词
        seg, hidden = self.ltp.seg(sentence)
        # 语义依存分析树(语义关系)
        sdp = self.ltp.sdp(hidden, mode='tree')
        # 语义句法分析(语法关系)
        dep = self.ltp.dep(hidden)
        # 语义角色标注(词语关系)
        srl = self.ltp.srl(hidden, keep_empty=False)
        # 命名实体识别(特殊名词的判断)
        # ner = self.ltp.ner(hidden)
        # 词性标注
        pos = self.ltp.pos(hidden)
        return seg, pos, srl, sdp, dep


if __name__ == '__main__':
    # 这个是测试
    ltp = LtpParser()
    sentence = '水仙为什么不开花'
    sents = ltp.split_sents(sentence)
    words, postags, child_dict_list, roles_dict, format_parse_list = ltp.parser_main([sents[0]])
    print(words[0])
    print(postags[0])
    print(child_dict_list[0])
    print(roles_dict[0])
    print(format_parse_list[0])
    result = ltp.rule(words[0], postags[0], child_dict_list[0], roles_dict[0], format_parse_list[0])
    print(result)
