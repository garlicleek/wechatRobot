步骤一: 打开neo4j数据库
cd root/neo4j/bin
./neo4j start

步骤二:新建窗口
screen -s wechat

步骤三:运行微信后端
cd root/wechat
sudo python main.py 80

步骤四:推出窗口
ctrl+A+D