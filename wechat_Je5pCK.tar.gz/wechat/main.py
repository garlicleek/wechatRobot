# -*- coding: utf-8 -*-
# filename: main.py
# function: 主程序
import web
from handle import Handle

urls = (
    '/wx', 'Handle',
)

if __name__ == '__main__':
    # 响应程序
    app = web.application(urls, globals())
    app.run()
    # 请求acess_token
        