from py2neo import Graph
import json


# 如果需要获取病虫害的相关知识需要保存字典{username,lastmsg}为json文件
class chatbot:
    def __init__(self):
        self.g = Graph("http://localhost:7474", auth=('neo4j', 'cauurp'))
        self.num_limit = 20

    def init_answer(self):
        a1 = '本公众号用以解决农业生产中常见作物的病虫害问题,请尝试通过以下关键词进行提问:\n'
        sql = 'MATCH (n:`作物种类`) RETURN n.name'
        res = self.g.run(sql).data()
        for i in range(len(res)):
            a1 += str(i) + '. ' + res[i]['n.name'] + '\n'
        return a1

    def chat_main(self, userid, sent):
        print('测试:已经进入chatbot')
        answer = self.init_answer()
        print('测试0')
        last_msg = self.review(userid)
        print('测试1')
        final_answer = self.search(userid, last_msg, sent)
        print('测试2')
        if not final_answer:
            return answer
        else:
            return final_answer

    def search(self, userid, msg, sent):
        sql_1 = "MATCH(n:`作物种类`) WHERE n.name = '{}' RETURN n.name".format(sent)
        res_1 = self.g.run(sql_1).data()
        print('search 1...')
        if res_1:
            self.save(userid, sent, '')

            a1 = "请输入想要了解的病虫害问题:\n"
            sql = "MATCH (n:`作物种类`{{name:'{}'}})-[*1]->(t)  WHERE NOT t.name='农作物' RETURN t.name".format(sent)
            res = self.g.run(sql).data()
            for i in range(len(res)):
                a1 += str(i) + '. ' + res[i]['t.name'] + '\n'
            return a1

        print('search 2...')
        sql_2 = "MATCH(n:`疾病名称`) WHERE n.name = '{}' RETURN n.name".format(sent)
        res_2 = self.g.run(sql_2).data()
        if msg['crop'] and res_2:
            self.save(userid, msg['crop'], sent)
            f_answer = '''请输入想要查询该病的相关知识:
            1. 多发地区
            2. 发病表现
            3. 防治措施'''
            return f_answer

        print('search 3...')
        info = ['多发地区', '发病表现', '防治措施']
        if msg['crop'] and msg['disease'] and sent in info:
            rel = ''
            if sent[0] == '多':
                rel = '多发于'
            elif sent[0] == '发':
                rel = '表现为'
            elif sent[0] == '防':
                rel = '的治疗措施有'
            sql = "MATCH (n:`疾病名称`{{name:'{0}'}})-[:`{1}`]->(t)  RETURN t.name".format(msg['disease'], rel)
            res = self.g.run(sql).data()
            try:
                f_answer = res[0]['t.name']
                return f_answer
            except KeyError and IndexError:
                print('not found the data!')
                return ''
        return ''

    def review(self, usrid):
        with open('book.json', 'r', encoding='utf-8') as file:
            print('file opened...')
            data = json.load(file)
            file.close()
            print('file closed...')
        if usrid in data.keys():
            msg = data[usrid]
        else:
            msg = {'crop': '', 'disease': ''}
        return msg

    def save(self, usrid, c, d):
        usr_info = {usrid: {'crop': c, 'disease': d}}
        json_str = json.dumps(usr_info)
        with open('book.json', 'w', encoding='utf-8') as file:
            file.write(json_str)
            file.close()
            


if __name__ == '__main__':
    handle = chatbot()
    while 1:
        question = input()
        answer = handle.chat_main('12345', question)
        print(answer)
        print("test:", handle.review('12345'))
